import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tokenexpire',
  templateUrl: './tokenexpire.component.html',
  styleUrls: ['./tokenexpire.component.css']
})
export class TokenexpireComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
